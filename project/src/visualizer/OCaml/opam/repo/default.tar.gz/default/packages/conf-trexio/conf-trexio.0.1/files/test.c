#include <trexio.h>

// compile with: gcc test.c -ltrexio

int main () {
  return 0;
}
